#
print('this is three')